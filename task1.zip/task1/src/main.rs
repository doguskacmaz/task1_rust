fn main() {

    let mut ad  = String::from("Dogus");

    let mut soyad = String::from (" Kacmaz");

    concantenated_strings(&mut ad, &mut soyad);

    println!("Adim Soyadim {}", ad);


}


fn concantenated_strings(ad:&mut String, soyad :&mut String) {
    ad.push_str( &soyad);
}